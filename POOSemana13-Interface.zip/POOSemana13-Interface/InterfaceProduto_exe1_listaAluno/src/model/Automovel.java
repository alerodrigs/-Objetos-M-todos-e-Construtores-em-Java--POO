package model;

public class Automovel implements IProduto{

	public String nome;
	public String marca;
	public double preco;
	
	public Automovel(String nome, String marca, double preco) {
		this.nome = nome;
		this.marca = marca;
		this.preco = preco;
	}
	
	@Override
	public String getNome() {
		return this.getNome();
	}

	@Override
	public String getMarca() {
		return this.getMarca();
	}

	@Override
	public double getPreco() {
		return this.getPreco();
	}
	
}
