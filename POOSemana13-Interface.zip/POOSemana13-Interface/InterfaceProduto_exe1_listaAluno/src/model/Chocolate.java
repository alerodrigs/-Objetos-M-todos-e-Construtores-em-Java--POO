package model;

public class Chocolate implements IProduto {

	@Override
	public String getNome() {
		return "crunch";
	}

	@Override
	public String getMarca() {
		return "garoto";
	}

	@Override
	public double getPreco() {
		return 10.80;
	}

}
