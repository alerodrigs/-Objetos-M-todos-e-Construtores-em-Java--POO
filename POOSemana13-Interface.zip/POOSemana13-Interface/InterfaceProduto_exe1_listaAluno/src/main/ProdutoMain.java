package main;

import model.Automovel;
import model.Chocolate;

public class ProdutoMain {

	public static void main(String[] args) {
		Automovel automovel = new Automovel("Camaro amarelo", "Chevrolet", 456.000);
		System.out.println("Informações do Automóvel: ");
		System.out.println("Nome: "+ automovel.nome + " Marca: "+ automovel.marca+ " Preço: "+ automovel.preco);
		
		Chocolate chocolate = new Chocolate();
		System.out.println("Nome: "+ chocolate.getNome()+ " Marca: "+ chocolate.getMarca() + " Preço: "+ chocolate.getPreco());
	}

}
