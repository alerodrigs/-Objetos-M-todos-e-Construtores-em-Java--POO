package main;

import model.Circulo;
import model.Quadrado;
import model.Retangulo;


public class FormaGeometricaMain {

	public static void main(String[] args) {
		Circulo circulo = new Circulo();
		circulo.raio = 40;
		System.out.println("A area do circulo: "+ circulo.area());
		System.out.println("O comprimento do circulo: "+ circulo.comprimento());

		Quadrado quadrado = new Quadrado();
		quadrado.largura = 19;
		quadrado.comprimento = 19;
		System.out.println("A area do quadrado: "+ quadrado.area());
		
		Retangulo retangulo = new Retangulo();
		retangulo.comprimento = 16;
		retangulo.largura = 3;
		System.out.println("A area do retangulo: "+ retangulo.area());
		System.out.println("O comprimento do retangulo: "+ retangulo.comprimento());
	}

}
