package model;

public class Circulo implements IFormaGeometrica{

	public double raio; 	
	public static final float pi = 3.14F;
	
	@Override
	public double area() {
		return raio * raio * Circulo.pi;
	}

	@Override
	public double comprimento() {
		return 2 * Circulo.pi * raio;
	}

}
