package main;

import java.util.InputMismatchException;
import java.util.Scanner;

import model.Divisao;
import model.IOperacaoMatematica;
import model.Multiplicacao;
import model.Soma;
import model.Subtracao;

public class OperacaoMatematicaMain {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		IOperacaoMatematica operacao;

		System.out.println("Opções de operações ------");
		System.out.println("1 - Soma");
		System.out.println("2 - Subtração");
		System.out.println("3 - multiplicação");
		System.out.println("4 - Divisao");
		System.out.println("Escolha uma opção: ");

		try {
			int opcao = scan.nextInt();
			switch (opcao) {
			case 1:
				operacao = new Soma();
				break;
			case 2:
				operacao = new Subtracao();
				break;
			case 3:
				operacao = new Multiplicacao();
				break;
			case 4:
				operacao = new Divisao();
				break;
			default:
				throw new InputMismatchException("Opção inexistente. Encerrando programa.");

			}

			System.out.println("Digite o primeiro numero (a): ");
			int a = scan.nextInt();

			System.out.println("Digite o segundo numero (b): ");
			int b = scan.nextInt();

			int resultado = operacao.Calcular(a, b);
			System.out.println(resultado);
		}

		catch (ArithmeticException e) {
			System.out.println(e.getMessage());
		} catch (InputMismatchException e) {
			if (e.getMessage() != null) {
				System.out.println(e.getMessage());
			} else {
				System.out.println("Erro: Tipo de dado não suportado ou inválido. Digite apenas números inteiros!");
			}
			
		}
	}
}
