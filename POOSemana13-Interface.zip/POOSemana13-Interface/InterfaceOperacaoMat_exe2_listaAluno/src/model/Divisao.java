package model;

public class Divisao implements IOperacaoMatematica {

	public Divisao() {
		
	}
	@Override
	public int Calcular(int a, int b) {
		if(b <= 0) {
		throw new ArithmeticException("Erro de divisão, escolha outro numero.");
		}		
		return a / b;
	}

}
