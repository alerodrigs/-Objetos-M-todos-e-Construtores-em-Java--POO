package model;

public interface IOperacaoMatematica {
	
	public int Calcular(int a, int b);
		
}
