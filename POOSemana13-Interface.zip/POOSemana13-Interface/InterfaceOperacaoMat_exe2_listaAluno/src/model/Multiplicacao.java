package model;

public class Multiplicacao implements IOperacaoMatematica {

	public Multiplicacao() {
		
	}
	@Override
	public int Calcular(int a, int b) {
		return a * b;
	}

}
