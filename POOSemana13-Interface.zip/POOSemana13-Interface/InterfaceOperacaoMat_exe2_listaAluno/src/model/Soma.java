package model;

public class Soma implements IOperacaoMatematica{

	public Soma(){
		
	}
	@Override
	public int Calcular(int a, int b) {
		return a + b;
	}
}
