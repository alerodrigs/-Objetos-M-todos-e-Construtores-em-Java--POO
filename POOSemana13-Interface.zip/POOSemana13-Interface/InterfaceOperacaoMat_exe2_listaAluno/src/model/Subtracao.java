package model;

public class Subtracao implements IOperacaoMatematica {
	public Subtracao() {
		
	}
	
	@Override
	public int Calcular(int a, int b) {
		return a - b;
	}
}
