package main;

import model.Coordenador;
import model.Diretor;
import model.IColaborador;
import model.Professor;

public class ColaboradorMain {

	public static void main(String[] args) {
		IColaborador professor = new Professor();
		System.out.println("O salario do professor: " + professor.obtemSalario());

		IColaborador coordenador = new Coordenador();
		System.out.println("O salário do coordenador: " + coordenador.obtemSalario());

		IColaborador diretor = new Diretor();
		System.out.println("O salario do diretor: "+ diretor.obtemSalario());
		}

}
